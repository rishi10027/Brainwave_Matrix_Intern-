import pandas as pd
import re
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
import joblib

def wordopt(text):
    text = text.lower()
    text = re.sub(r'\[.*?\]', '', text)
    text = re.sub(r"\\W", " ", text)
    text = re.sub(r'https?://\S+|www\.\S+', '', text)
    text = re.sub(r'<.*?>+', '', text)
    text = re.sub(r'[%s]' % re.escape(string.punctuation), '', text)
    text = re.sub(r'\w*\d\w*', '', text)
    return text

# Load data
data_fake = pd.read_csv('Fake.csv')
data_true = pd.read_csv('True.csv')

# Prepare data
data_fake["class"] = 0
data_true['class'] = 1

# Use .copy() to avoid the SettingWithCopyWarning
data_fake_manual_testing = data_fake.tail(10).copy()
data_fake = data_fake.iloc[:-10]

data_true_manual_testing = data_true.tail(10).copy()
data_true = data_true.iloc[:-10]

data_fake_manual_testing.loc[:, 'class'] = 0
data_true_manual_testing.loc[:, 'class'] = 1

data_merge = pd.concat([data_fake, data_true], axis=0)
data = data_merge.drop(['title', 'subject', 'date'], axis=1)
data['text'] = data['text'].apply(wordopt)

x = data['text']
y = data['class']
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25)

vectorization = TfidfVectorizer()
xv_train = vectorization.fit_transform(x_train)
xv_test = vectorization.transform(x_test)

# Train models
LR = LogisticRegression()
LR.fit(xv_train, y_train)
joblib.dump(LR, 'LR_model.pkl')

DT = DecisionTreeClassifier()
DT.fit(xv_train, y_train)
joblib.dump(DT, 'DT_model.pkl')

GB = GradientBoostingClassifier(random_state=0)
GB.fit(xv_train, y_train)
joblib.dump(GB, 'GB_model.pkl')

RF = RandomForestClassifier(random_state=0)
RF.fit(xv_train, y_train)
joblib.dump(RF, 'RF_model.pkl')

joblib.dump(vectorization, 'vectorizer.pkl')
